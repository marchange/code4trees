// script.js
const countEl = document.getElementById('count');
const lengthEl = document.getElementById('length');
const out = document.getElementById('output');
const btn = document.getElementById('generate');

function show(msg) {
  out.textContent = msg;
}

btn.addEventListener('click', async () => {
  const requested = Number(countEl.value);
  const length = Number(lengthEl.value) || 12;

  // Client-side limit: blocks sending >10
  if (requested > 10) {
    alert('Client-side limit: maximum 10 passwords per run');
    return;
  }

  show('Requesting ' + requested + ' passwords...');

  const resp = await fetch('/generate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ count: requested, length })
  });

  const json = await resp.json();
  show(JSON.stringify(json, null, 2));
});

const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// Predefined alphabet (a-z, A-Z, 0-9 + symbols)
const alphabet = [];
for (let i = 97; i <= 122; i++) alphabet.push(String.fromCharCode(i)); // a-z
for (let i = 65; i <= 90; i++) alphabet.push(String.fromCharCode(i)); // A-Z
for (let i = 48; i <= 57; i++) alphabet.push(String.fromCharCode(i)); // 0-9
['!', '@', '#', '$', '%', '^', '&', '*'].forEach(s => alphabet.push(s));

function generatePassword(length = 12) {
  let pw = '';
  for (let i = 0; i < length; i++) {
    pw += alphabet[Math.floor(Math.random() * alphabet.length)];
  }
  return pw;
}

// No server-side limit on purpose
app.post('/generate', (req, res) => {
  const count = parseInt(req.body.count) || 0;
  const length = parseInt(req.body.length) || 12;

  const result = [];
  for (let i = 0; i < count; i++) {
    result.push(generatePassword(length));
  }

  res.json({
    requested: count,
    returned: result.length,
    passwords: result
  });
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
